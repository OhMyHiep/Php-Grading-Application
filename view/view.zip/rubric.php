<?php

?>
<!DOCTYPE html>
<head>
    <title>Capstone</title>
    <script defer src="rubric_layout.js"></script>
</head>

<body>
    <h1> Rubric Page</h1>
    <button id=newquestion type="button">
            New Question
    </button> <br>
    
    <form action="rubric_inc.php" method="POST" id="rubric">
        <button type="submit" name="submit" id="submitRubric">Submit Rubric</button>
    </form>

</body>
</html>







